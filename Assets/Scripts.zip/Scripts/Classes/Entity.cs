using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity
{
    public int UniqueId;
    public Vector3 Position;
    public GameObject EntityObject;
    public int yaw;
    public int pitch;
    public InterpolateMovement InterpolateMove;
}
